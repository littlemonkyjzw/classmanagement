import Vue from 'vue'
import ElementUI from 'element-ui';
import Scrollbar from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue'
import $ from 'jquery'
import * as echarts from 'echarts'

window.jQuery = $;
window.$ = $;

Vue.use(Scrollbar)
Vue.config.productionTip = false
Vue.use(ElementUI);
Vue.prototype.$echarts=echarts

new Vue({
  render: h => h(App),
  beforeCreate() {
  	Vue.prototype.$bus=this
	Vue.prototype.$user={}
  }
}).$mount('#app')
