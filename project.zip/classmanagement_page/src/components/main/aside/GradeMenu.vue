<template>
	<div >
		<el-submenu index="2" >
			<template slot="title" >
				<i class="el-icon-s-claim"></i>
				<span>成绩</span>
			</template>
			<el-menu-item-group>
				<el-menu-item index="2-1" @click="showGrade">
					<i class="el-icon-s-grid"></i>
					<span>数据表</span>
				</el-menu-item>
				<el-menu-item index="2-2" @click="showGradePic">
					<i class="el-icon-s-data"></i>
					<span>数据图</span>
				</el-menu-item>
			</el-menu-item-group>

		</el-submenu>		
	</div>


</template>

<script>
	export default{
		name:'GradeMenu',
		methods:{
			showGrade(){
				this.$bus.$emit('showPage',1)
			},
			showGradePic(){
				this.$bus.$emit('showPage',2)
			}
		}
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}

</style>