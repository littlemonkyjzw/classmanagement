<template>
	<div>
		<el-row class="tac">
			<el-col class="col" >
				<el-menu
				default-active="1"
				background-color="#55586c"
				text-color="#fff"
				active-text-color="#ffd04b"
				class="asmenu">
					<BasicInfo></BasicInfo>
					<GradeMenu></GradeMenu>
					<Fraction></Fraction>
					<Task></Task>
					<Location></Location>
					<Violation></Violation>
					<VisualData></VisualData>
				</el-menu>
			</el-col>
		</el-row>		
	</div>

</template>

<script>
	import GradeMenu from './GradeMenu.vue'
	import BasicInfo from './BasicInfo.vue'
	import Fraction from './Fraction.vue'
	import Task from './Task.vue'
	import Location from './Location.vue'
	import Violation from './Violation.vue'
	import VisualData from './VisualData.vue'
	
	export default{
		name:'MainAside',
		components:{
			GradeMenu,BasicInfo,Fraction,Task,Location,Violation,VisualData
		}
	}
</script>

<style scoped>
	.col{
		height: 100%;
	}
	.asmenu{
		height: 100vh;
	}
</style>