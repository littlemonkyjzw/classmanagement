<template>
	<el-submenu index="4" >
		<template slot="title">
			<i class="el-icon-s-cooperation"></i>
			<span>任务</span>
		</template>
		<el-menu-item-group>
			<el-menu-item index="4-1">
				<i class="el-icon-s-promotion"></i>
				<span>发布</span>
			</el-menu-item>
			<el-menu-item index="4-2">
				<i class="el-icon-search"></i>
				<span>查询</span>
			</el-menu-item>
		</el-menu-item-group>
	</el-submenu>
</template>

<script>
	export default{
		name:'Task'
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}

</style>