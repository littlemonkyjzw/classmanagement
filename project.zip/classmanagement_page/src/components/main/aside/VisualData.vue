<template>	
	<el-menu-item index="7" @click="showBasicInfo" >
		<i class="el-icon-s-order"></i>
		<span slot="title">数据可视化</span>
	</el-menu-item>
</template>

<script>
	export default{
		name:'VisualDate',
		methods:{
			showBasicInfo(){
				this.$bus.$emit('showScreen',1)
				this.$bus.$emit('showPage',10)
			}
		}
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}
</style>