<template>
	<el-submenu index="3" >
		<template slot="title">
			<i class="el-icon-star-on"></i>
			<span>积分</span>
		</template>
		<el-menu-item-group>
			<el-menu-item index="3-1">
				<i class="el-icon-s-grid"></i>
				<span>积分列表</span>
			</el-menu-item>
			<el-menu-item index="3-2">
				<i class="el-icon-s-data"></i>
				<span>积分图表</span>
			</el-menu-item>
		</el-menu-item-group>
	</el-submenu>
</template>

<script>
	export default{
		name:'Fraction'
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}


</style>