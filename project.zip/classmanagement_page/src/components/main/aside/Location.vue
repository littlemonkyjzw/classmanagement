<template>
	<el-menu-item index="5" >
		<i class="el-icon-position"></i>
		<span>位置</span>
	</el-menu-item>
</template>

<script>
	export default{
		name:'Location'
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}

</style>