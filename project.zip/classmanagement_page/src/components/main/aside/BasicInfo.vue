<template>
	<el-menu-item index="1" @click="showBasicInfo" >
		<i class="el-icon-s-order"></i>
		<span slot="title">基本信息</span>
	</el-menu-item>
</template>

<script>
	export default{
		name:"BasicInfo",
		methods:{
			showBasicInfo(){
				this.$bus.$emit('showPage',0)
			}
		}
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}

</style>