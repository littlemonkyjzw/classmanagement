<template>
	<el-submenu index="6" >
		<template slot="title">
			<i class="el-icon-tickets"></i>
			<span>不良记录</span>
		</template>
		<el-menu-item-group>
			<el-menu-item index="6-1">
				<i class="el-icon-search"></i>
				<span>查询</span>
			</el-menu-item>
			<el-menu-item index="6-2">
				<i class="el-icon-s-tools"></i>
				<span>修改</span>
			</el-menu-item>
		</el-menu-item-group>
	</el-submenu>
</template>

<script>
	export default{
		name:'Violation'
	}
</script>

<style scoped>
	span{
		font-size: 17px;
	}

</style>