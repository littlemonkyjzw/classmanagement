<template>
	<div ref="scr" @click="closeScreen" class="box">
		<div class="header">
			班级管理系统数据显示板
		</div>
		<Body></Body>
	</div>
</template>

<script>
	
	import Body from './Body.vue'
	
	export default{
		name:'Main',
		methods:{
			closeScreen(){
				this.$bus.$emit('showScreen',0)
				this.$bus.$emit('showPage',1)
			}
		},
		mounted() {
			this.$refs.scr.requestFullscreen();
		},
		components:{
			Body
		}
	}
</script>

<style scoped>
	
	.box{
		width: 100%;
		height: 90%;
		margin: 0;
		background-image: url('../../../../assets/visual/bg3.jpg');
		background-size: 100% 100%;

	}
	
	.header{
		width: 100%;
		height: 10%;
		background-image: url('../../../../assets/visual/head_bg.png');
		color: white;
		text-align: center;
		font-size: 50px;
		background-size: 100% 100%;
		
	}

	


</style>