<template>
	<div class="boxd">
		<div class="topb">
			<RightBottomData></RightBottomData>
		</div >
		
		<div class="centerb">
			<RightCenterData></RightCenterData>
		</div>
		
		<div class="bottomb">
			<RightTopData></RightTopData>
		</div>
	</div>
</template>

<script>
	import RightTopData from './RightTopData.vue'
	import RightCenterData from './RightCenterData.vue'
	import RightBottomData from './RightBottomData.vue'
	
	export default{
		name:'RightData',
		components:{
			RightTopData,RightCenterData,RightBottomData
		}
	}
</script>

<style scoped>
	
	.boxd{
		width: 100%;
		height: 100%;
		display: inline-block;
		position: relative;
	}
	
	.topb{
		width: 97%;
		height: 30%;
		margin: 9px 0 5px 5px;
		border: 1px #40a2ec dotted;
		background-image: url('../../../../assets/visual/line.png');
		background-size: 100% 100%;
		position: relative;
	}
	
	.centerb{
		width: 97%;
		height: 30%;
		margin: 9px 0 5px 5px;
		border: 1px #40a2ec dotted;
		background-image: url('../../../../assets/visual/line.png');
		background-size: 100% 100%;
		position: relative;
	}
	
	.bottomb{
		width: 97%;
		height: 30%;
		margin: 9px 0 5px 5px;
		border: 1px #40a2ec dotted;
		background-image: url('../../../../assets/visual/line.png');
		background-size: 100% 100%;
		position: relative;
	}
	.bottomb:hover::before,.centerb:hover::before,.topb:hover::before{
		content: "";
		position: absolute;
		top:-5px;
		right: -5px;
		left: -5px;
		bottom: -5px;
		width: 100% + 5px;
		height: 100% + 5px;
		border: #19ffdd solid 2px;
		animation: item 5s infinite linear;
	}
	
	.bottomb:hover::after,.centerb:hover::after,.topb:hover::after{
		content: "";
		position: absolute;
		top:-5px;
		right: -5px;
		left: -5px;
		bottom: -5px;
		width: 100% + 5px;
		height: 100% + 5px;
		border: #ff1808 solid 2px;
		animation: item1 5s infinite linear;
	}
	
	
	
	@keyframes item {
	        0%{ clip-path: inset(0 98% 0 0 );}
	
	        25%{ clip-path: inset( 98% 0 0 0 );}
	
	        50%{ clip-path: inset( 0 0 0 98% );}
	
	        75%{ clip-path: inset( 0 0  98% 0 );}
	
	        100%{clip-path: inset(0 98% 0 0 );}
	}
	
	@keyframes item1 {
	    0%{ clip-path: inset(0 0 0 98% );}
	
	    25%{ clip-path: inset( 0 0 98% 0 );}
	
	    50%{ clip-path: inset( 0 98% 0  0 );}
	
	    75%{ clip-path: inset( 98% 0   0 0 );}
	
	    100%{clip-path: inset(0  0 0 98% );}
	}
	
</style>