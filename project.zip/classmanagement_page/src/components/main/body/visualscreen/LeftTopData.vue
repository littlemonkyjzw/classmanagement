<template>
	<div class="container" ref="box">
		
	</div>
</template>

<script>
	export default{
		name:'LeftTopData',
		mounted() {
			var mychar = this.$echarts.init(this.$refs.box)
			var option = {
				title:{text:'各科实际分数',left:'center',textStyle:{color:'#fff'}},
				tooltip:{trigger:'axis',axisPointer:{type:'shadow'}},
				xAxis:{data:['语文','数学','英语','历史','地理','生物','化学','物理','政治'],axisLine:{lineStyle:{color:'#ccc'}}},
				yAxis:{splitLine:{show:false},axisLine:{lineStyle:{color:'#ccc'}}},
				series:[
					{name:'bar',type:'bar',barWidth:10,itemStyle:{borderRadius:5,color:new this.$echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'#14c8d4'},{ offset: 1, color: '#43eec6' }])},data:[]},
					{name:'line',type:'bar',barGap:'-100%',barWidth:10,itemStyle:{color:new this.$echarts.graphic.LinearGradient(0,0,0,1,[{ offset: 0, color: 'rgba(20,200,212,0.5)' },
			      { offset: 0.2, color: 'rgba(20,200,212,0.2)' },
			      { offset: 1, color: 'rgba(20,200,212,0)' }])},z:-12,data:[100,100,100,100,100,100,100,100,100]},
				  {name:'dotted',type:'pictorialBar',symbol:'rect',itemStyle:{color:'#0f375f'},symbolRepeat:true,symbolSize:[12,4],symbolMargin:1,z:-10,data:[100,100,100,100,100,100,100,100,100]}
				],grid:{ // 让图表占满容器
					top:"35vh",left:"60vh",right:"30vh",bottom:"20vh"}

			}
			
			$.ajax({
				url:'/api/clsmgent/grade/total',
				type:'get',
				dataType:'json',
				success:(res)=>{
					option.series[0].data=res
					$.ajax({
						url:'/api/clsmgent/ShowStuInfo/num',
						type:'get',
						success:(res)=>{
							option.series[1].data=[res*100,res*100,res*100,res*100,res*100,res*100,res*100,res*100,res*100]
							option.series[2].data=[res*100,res*100,res*100,res*100,res*100,res*100,res*100,res*100,res*100]
							mychar.setOption(option)
							this.$forceUpdate()							
						}
					})

				},
				error:()=>{
					this.$message.error('后端接口连接异常')
				}
			})
			
		}
	}
	

	
	
</script>

<style scoped>
	
	.container{
		width: 100%;
		height: 100%;
	}
</style>