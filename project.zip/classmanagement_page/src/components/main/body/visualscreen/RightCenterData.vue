<template>
	<div class="container" ref="box"></div>
</template>

<script>
	export default{
		name:'RightCenterData',
		mounted() {
			var echar = this.$echarts.init(this.$refs.box,null,{width:250,height:250})
			
			var option={
				tooltip:{fomatter:'{a} <br/> {b}:{c}%'},
				grid:{left:'center',top:'middle'} ,
				series:[
					{name:'系统使用人数',type:'gauge',progress:{show:true},detail:{valueAnimation:true,formatter:'{value}'},
					min:0,max:30,
					itemStyle:{color:'#58d9f9',shadowColor:'rgba(0,138,255,0.45)',shadowBlur:10,shadowOffsetX:2,shadowOffsetY:2},
					progress:{show:true,roundCap:true,width:10},
					detail:{color:'#58d9f9'},
					data:[{name:'使用人数'}]}
				]
				  
			}
			
			$.ajax({
				url:'/api/clsmgent/getRegNum',  
				type:'get',
				success:(res)=>{
					option.series[0].data[0].value=res
					echar.setOption(option) 
					this.$forceUpdate()
				}
			})
		}
	}
	

</script>

<style scoped>
	.container{
		padding-left: 25%;
		padding-right: 25%;
		width: 100%;
		height: 100%;
	}
</style> 