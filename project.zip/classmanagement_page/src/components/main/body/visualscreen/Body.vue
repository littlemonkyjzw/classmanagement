<template>
	<div class="box">
		<div class="left">
			<LeftData></LeftData>
		</div>
		
		<div class="center">
			<CenterData></CenterData>
		</div>
		
		<div class="right">
			<RightData></RightData>
		</div>
	</div>
</template>

<script>
	import CenterData from './CenterData.vue'
	import LeftData from './LeftData.vue'
	import RightData from './RightData.vue'
	
	export default{
		name:'Body',
		components:{
			CenterData,LeftData,RightData
		}
	}
</script>

<style scoped>
	.box{
		height: 95%;
		width: 100%;
		display: flex;
	}
	
	.left{
		margin: 3px;
		width: 33%;
		height: 100%;
		float: left;
	}
	.center{
		margin: 3px;
		width: 33%;
		height: 100%;
		float: left;
	}
	.right{
		margin: 3px;
		width: 33%;
		height: 100%;
		float: left;
	}
</style>