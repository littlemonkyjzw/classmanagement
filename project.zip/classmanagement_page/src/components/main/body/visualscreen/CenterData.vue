<template>
	<div class="centerd">
		<div class="time"><p>{{time}}</p></div>
		<div class="datac" ref="databox"></div>
	</div>
</template>

<script>
	export default{
		name:'CenterData',
		data() {
			return{
				time:'',
				totalNum:0,
				totalGrad:[]
			}
		},
		methods:{

		},
		mounted() {
			setInterval(()=>{
				var date = new Date()
				var y = date.getFullYear();
				var m = date.getMonth()+1;
				var d = date.getDate();
				var h = date.getHours();
				var min = date.getMinutes();
				var sec = date.getSeconds();
				m = m < 10 ? "0"+m : m;
				d = d < 10 ? "0"+d : d;
				h = h<10 ? "0"+h :  h;
				min = min<10 ? "0"+min : min;
				sec = sec<10 ? "0"+sec : sec;			
				this.time=y+'年'+m+'月'+d+"日 "+h+":"+min+":"+sec;
			},100)
			
			$.ajax({
				url:'/api/clsmgent/ShowStuInfo/num',
				type:'get',
				success:(res)=>{
					this.totalNum=res*100
					option.radar.indicator=[{ name: '语文',max:this.totalNum}, { name: '数学',max:this.totalNum},{ name: '英语',max:this.totalNum},
						{ name: '历史',max:this.totalNum},{ name: '地理',max:this.totalNum},{ name: '生物',max:this.totalNum},{ name: '化学',max:this.totalNum},
						{ name: '物理',max:this.totalNum},{ name: '政治',max:this.totalNum}]
					$.ajax({
						url:'/api/clsmgent/grade/total',
						type:'get',
						success:(res)=>{
							option.series[0].data=[res]
							echart.setOption(option)
							this.$forceUpdate()
						},
						error:()=>{
							this.$message.error('后端接口连接失败')
						}
					})
				},
				error:()=>{
					this.$message.error('后端接口连接异常')
				}
			})
			
			var echart = this.$echarts.init(this.$refs.databox)
			
			var lineStyle={width:2,opacity:0.5};
			
			
			var option={
				title:{text:'各科总分分布图',left:'center',textStyle:{color:'#1db0ee',fontSize:'25px'}},tooltip:{},
				legend:{bottom:5,data:['各科总分分布图'],textStyle:{color:'#fff'},selectedMode:'single'},
				radar:{splitNumber:5,axisName:{color:'rgb(123,130,254)',fontSize:'20px'},splitLine:{lineStyle:{color:['rgba(126, 197, 223, 0.9)',
				'rgba(126, 197, 223, 0.2)','rgba(126, 197, 223, 0.3)','rgba(126, 197, 223, 0.4)','rgba(126, 197, 223, 0.6)','rgba(126, 197, 223, 0.8)'].reverse()}},
				  splitArea:{show:false},axisLine:{lineStyle:{color:'rgba(238,197,102,0.3)'}}},
				series:[{name:'各科总成绩',type:'radar',lineStyle:lineStyle,symbol:'none',itemStyle:{color:'#50e9f1'},areaStyle:{opacity:0.4}}]
			}
			

			
			
		}
	}
	

	
</script>

<style scoped>
	.centerd{
		width: 100%;
		height: 100%;
	}
	
	.time{
		font-size: 30px;
		color: #d9ec28;
		text-align: center;
		width: 100%;
		height: 20%;
	}
	
	.datac{
		width: 100%;
		height: 80%;
	}
</style>