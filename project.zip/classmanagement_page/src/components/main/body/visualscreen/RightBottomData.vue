<template>
	<div class="container" ref="box">
		
	</div>
</template>

<script>
	export default{
		name:'RightBottomData',
		mounted() {
			var echart = this.$echarts.init(this.$refs.box)
			
			var option = {
				tooltip:{trigger:'item'},
				xAxis:{type:'category',data:['账号状态正常','账号已冻结']},
				yAxis:{type:'value',splitLine: { show: false },axisLine:{lineStyle:{color:'#ccc'}}},
				series:[{data:[{itemStyle:{color:'#15ff24'}},{itemStyle:{color:'#ff3a18'}}],barWidth:20,type:'bar'}],
				grid:{top:20,bottom:20} 
			} 
			
			$.ajax({
				url:'/api/clsmgent/StatusNum',
				type:'get',
				dataType:'json',
				success:(res)=>{
					option.series[0].data[0].value=res.qua
					option.series[0].data[1].value=res.disqua
					echart.setOption(option)
					this.$forceUpdate()
				}
			})
		}
	}
</script>

<style scoped>
	.container{
		width: 100%;
		height: 100%;
	}
</style>