<template>
	<div class="box">
		<div class="leftdata" ref="totalnum" ></div>
		
		<div class="centerdata" ref="man"></div>
		
		<div class="rightdata" ref="women"></div>
	</div>
</template>

<script>
	export default{
		name:'RightTopData',
		mounted() {
			var totaldata = this.$echarts.init(this.$refs.totalnum)
			var mandata = this.$echarts.init(this.$refs.man)
			var womandata = this.$echarts.init(this.$refs.women)
			
			var optiontotal = {
				tooltip:{trigger:'item'},
				color:['#18f4ff','#1f6184'],
				series:[{name:'班级人数信息',type:'pie',radius:['40%','70%'],label:{show:true,position:'center',fontSize:'20px'},
				data:[{value:0,name:'班级总人数',itemStyle:{normal:{shadowBlur:15,shadowColor:'#1f6184'}}},{value:10,name:''}]}]
			}
			
			var optionman={
				tooltip:{trigger:'item'},
				color:['#ffd52c','#1f6184'],
				title:{text:'班级人数信息',textStyle:{color:'#fff'},left:'center'},
				series:[{name:'班级人数信息',type:'pie',radius:['40%','70%'],label:{show:true,fontSize:'20px',position:'center'},
				data:[{value:0,name:'男生人数',itemStyle:{normal:{shadowBlur:15,shadowColor:'#1f6184'}}},{name:''}]}]
			}
			
			var optionwo={
				tooltip:{trigger:'item'}, 
				color:['#ebff2f','#1f6184'],
				series:[{name:'班级人数信息',type:'pie',radius:['40%','70%'],label:{show:true,position:'center',fontSize:'20px'},
				data:[{value:0,name:'女生人数',itemStyle:{normal:{shadowBlur:15,shadowColor:'#1f6184'}}},{name:''}]}
				],
				grid:{top:'20vh',left:'0vh',bottom:'0vh',right:'0vh'}
			}
			
			$.ajax({
				url:'/api/clsmgent/ShowStuInfo/numInfo',
				dataType:'json',
				type:'get',
				success:(res)=>{
					optiontotal.series[0].data[0].value=res.totalNum
					optionman.series[0].data[0].value=res.man
					optionman.series[0].data[1].value=res.man-3
					optionwo.series[0].data[0].value=res.woman
					optionwo.series[0].data[1].value=res.woman-3
					totaldata.setOption(optiontotal)
					mandata.setOption(optionman)
					womandata.setOption(optionwo)
					this.$forceUpdate()
				}
			})
			
		}
	}
</script>

<style scoped>
	.box{
		width: 100%;
		height: 100%;
		display: flex;
	}
	
	.leftdata{
		width: 30%;
		height: 100%;
		margin: auto;
	}
	
	.centerdata{
		width: 30%;
		height: 100%;
		margin: auto;
	}
	
	.rightdata{
		width: 30%;
		height: 100%;
		margin: auto;
	}
</style>