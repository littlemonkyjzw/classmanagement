<template>
	<div class="container" ref="box"></div>
</template>

<script>
	export default{
		name:'LeftCenterData',
		mounted() {
			var chart = this.$echarts.init(this.$refs.box)
			
			var option={
				title:{text:'历史考试总分曲线',left:'center',textStyle:{color:'#fff'}},
				tooltip:{trigger:'axis',axisPointer:{type:'shadow'}},
				xAxis:{data:[],axisLine:{lineStyle:{color:'#ccc'}}},
				yAxis:{splitLine:{show:false},axisLine:{lineStyle:{color:'#ccc'}}},
				series:[{name:'line',type:'line',smooth:true,showAllSymbol:true,symbol:'emptyCircle',symbolSize:15,data:[],
						itemStyle:{color:'#3a84ff'},
						areaStyle:{
							color:{
							type:'liner',x:0, y:0, x2:0, y2:1,
							colorStops: [{offset: 0, color: 'rgba(7, 255, 255, 0.5)'},  // 0% 处的颜色
							{offset: 1, color: 'rgba(11, 251, 255, 0.0)'}],
							global:false} // 100% 处的颜色							
						}
						}],
					grid:{top:"35vh",left:"60vh",right:"30vh",bottom:"20vh"} // 让图表占满容器
			}
			$.ajax({
				url:'/api/clsmgent/grade/AllTotalGrade',
				type:'get',
				dataType:'json',
				success:(res)=>{
					option.series[0].data=res[0]
					option.xAxis.data=res[1]
					chart.setOption(option)
					this.$forceUpdate()
				},
				error:()=>{
					this.$message.error('后端接口连接异常')
				}
			})
		}
	}
</script>

<style scoped>
	.container{
		width: 100%;
		height: 100%;
	}
</style>