<template>
	<div class="container" ref="box"></div>
</template>

<script>
	export default{
		name:'LeftBottomData',
		mounted() {
			var charts = this.$echarts.init(this.$refs.box)
			
			var option = {
				tooltip:{},
				title:{text:'班级积分合格率',textStyle:{color:'#fff'},left:'center'},
				color:['#18f4ff','#1f6184'],
				series:[{name:'积分合格率',type:'pie',radius:['40%','70%'],itemStyle:{borderRadius:5,borderWidth:1},
						label:{show:true,fontSize:'20px',position:'center'},
						data:[{value:0,name:'合格百分比',itemStyle:{normal:{shadowBlur:15,shadowColor:'#1cfff0'}}},
								{value:0,name:'不合格百分比',itemStyle:{normal:{shadowBlur:15,shadowColor:'#1f6184'}}}]
				}],
				grid:{top:"20vh",left:"20vh",right:"10vh",bottom:"10vh"}
			}
			
			$.ajax({
				url:'/api/clsmgent/Fraction/qua',
				type:'get',
				success:(res)=>{
					$.ajax({
						url:'/api/clsmgent/ShowStuInfo/num',
						type:'get',
						success:(toNum)=>{
							var b = res*100/toNum
							var b1 = (toNum-res)*100/toNum
							option.series[0].data[0].value=b.toFixed(0)
							option.series[0].data[1].value=b1.toFixed(0)
							charts.setOption(option)
							this.$forceUpdate()
						}
					})
				}
			})
	}
}
</script>

<style scoped>
	.container{
		width: 100%;
		height: 100%;
	}
</style>