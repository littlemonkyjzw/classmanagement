<template>
	<div class="box">
		<div class="updateArea"">
			<el-input suffix-icon="el-icon-collection-tag" placeholder="输入学号" v-model="stuInfo.code" ></el-input>
			<el-input suffix-icon="el-icon-collection-tag" placeholder="输入姓名" v-model="stuInfo.stuname" ></el-input>
			<el-select v-model="stuInfo.stugender" placeholder="请选择性别">
				<el-option value="男"></el-option>
				<el-option value="女"></el-option>
			</el-select>
			<el-date-picker v-model="stuInfo.stubirth" type="date" placeholder="选择日期" :picker-options="pickerOptions"  ></el-date-picker>
			<el-input suffix-icon="el-icon-collection-tag" placeholder="输入手机号" v-model="stuInfo.stuphone" ></el-input>
			<el-input suffix-icon="el-icon-collection-tag" placeholder="输入家庭住址" v-model="stuInfo.stuaddress" ></el-input>
			<el-select v-model="stuInfo.stupos" placeholder="请选择职位">
				<el-option value="班主任"></el-option>
				<el-option value="班长"></el-option>
				<el-option value="班委"></el-option>
				<el-option value="学生"></el-option>
			</el-select>
			<el-button type="primary" circle icon="el-icon-plus" @click="addInfo"></el-button>
			<el-button type="primary" circle icon="el-icon-edit" @click="editInfo"></el-button>
			<el-button type="primary" circle icon="el-icon-delete" @click="delInfo"></el-button>
			<el-button type="primary" circle icon="el-icon-s-open" @click="clearInfo"></el-button>
		</div>
		
		<div class="showInfo">
				<el-table
				:data="tableData" border style="width: 100%;" height="100%" class="table"
				@current-change="getrow"
				highlight-current-row>
					<el-table-column prop="code" label="学号" ></el-table-column>
					<el-table-column prop="stuname" label="姓名"  ></el-table-column>
					<el-table-column prop="stugender" label="性别"  ></el-table-column>
					<el-table-column prop="stubirth" label="出生日期"  ></el-table-column>
					<el-table-column prop="stuphone" label="手机号"  ></el-table-column>
					<el-table-column prop="stuaddress" label="家庭住址"  ></el-table-column>
					<el-table-column prop="stupos" label="职位" ></el-table-column>
				</el-table>				
		</div>
	</div>
</template>

<script>
import { type } from 'jquery';
	export default{
		name:'BaseInfoView',
		data() {
			return{
				tableData:[],
				stuInfo:{
					code:'',stuname:'',stugender:'',stubirth:'',stuphone:'',stuaddress:'',stupos:'',stuposCode:1,stugenderCode:1
				},
				pickerOptions:{
				    disabledDate(time) {
				        return time.getTime() > Date.now();
				    }
				}
			}
		},
		methods:{

			getGrad(){
				$.ajax({
					url:'/api/clsmgent/ShowStuInfo',
					type:"get",
					dataType:"json",
					success:(res)=>{
						this.tableData=res;
						this.$forceUpdate()
					}
				})
			},
			//获取当前行
			getrow(currentRow,oldCurrentRow){
				if(currentRow){
					this.stuInfo.code=currentRow.code
					this.stuInfo.stuname=currentRow.stuname
					this.stuInfo.stugender=currentRow.stugender
					this.stuInfo.stubirth=currentRow.stubirth
					this.stuInfo.stuphone=currentRow.stuphone
					this.stuInfo.stuaddress=currentRow.stuaddress
					this.stuInfo.stupos=currentRow.stupos					
				}

			},
			clearInfo(){
				this.stuInfo.code='';this.stuInfo.stuname='';this.stuInfo.stugender='';
				this.stuInfo.stuaddress='';this.stuInfo.stubirth='';this.stuInfo.stuphone='';this.stuInfo.stupos=''
			},
			addInfo(){
				if(!this.stuInfo.stuname.trim() || !this.stuInfo.stugender.trim() || !this.stuInfo.stubirth.trim()
					|| !this.stuInfo.stuphone.trim() || !this.stuInfo.stuaddress.trim() || !this.stuInfo.stupos.trim()){
					this.$message({message:'请输入正确的信息',type:'warning'})
					return
				}
				$.ajax({
					url:'/api/clsmgent/ShowStuInfo',
					data:JSON.stringify(this.stuInfo),
					contentType:'application/json',
					type:'post',
					success:(res)=>{
						if(res == "添加成功"){
							this.$message({message:res,type:'success'})
							this.getGrad()
							return
						}
						this.$message.error(res)
					}
				})
				this.getGrad()
			},
			editInfo(){
				if(!this.stuInfo.stuname.trim() || !this.stuInfo.stugender.trim() || this.stuInfo.stubirth==null
					|| !this.stuInfo.stuphone.trim() || !this.stuInfo.stuaddress.trim() || !this.stuInfo.stupos.trim()){
					this.$message({message:'请输入正确的信息',type:'warning'})
					return
				}
				$.ajax({
					url:'/api/clsmgent/ShowStuInfo',
					data:JSON.stringify(this.stuInfo),
					contentType:'application/json',
					type:'put',
					success:(res)=>{
						if(res == "修改成功"){
							this.$message({message:res,type:'success'})
							this.getGrad()
							return
						}
						this.$message.error(res)
					}
				})
			},
			delInfo(){
				if(!this.stuInfo.stuname.trim() || !this.stuInfo.stugender.trim() || this.stuInfo.stubirth==null
					|| !this.stuInfo.stuphone.trim() || !this.stuInfo.stuaddress.trim() || !this.stuInfo.stupos.trim()){
					this.$message({message:'请输入正确的信息',type:'warning'})
					return
				}
				$.ajax({
					url:'/api/clsmgent/ShowStuInfo/'+this.stuInfo.code,
					data:JSON.stringify(this.stuInfo),
					contentType:'application/json',
					type:'delete',
					success:(res)=>{
						if(res == "删除成功"){
							this.$message({message:res,type:'success'})
							this.getGrad()
							return
						}
						this.$message.error(res)
					}
				})
			}
		},
		computed:{
			gen(){
				if(this.stuInfo.stugender == "男"){
					 this.stuInfo.stugenderCode=1
					 return
				}else{
					this.stuInfo.stugenderCode=2
					return
				}
			},
			
			pos(){
				if(this.stuInfo.stupos == "班主任"){
					this.stuInfo.stuposCode=1
					return
				}else if(this.stuInfo.stupos == "班委"){
					this.stuInfo.stuposCode=3
						return
				}else if(this.stuInfo.stupos == "班长"){
					this.stuInfo.stuposCode=2
						return
				}else{
					this.stuInfo.stuposCode=4
						return
				}		
			}			
			

			
		},
		
		mounted() {
			this.getGrad();
		}
	}
</script>

<style scoped>
	.box{
		height: 100%;
	}
	
	.updateArea{
		height: 10%;
	}
	.showInfo{
		height: 90%;
	}
	
	.el-table--scrollable-y .el-table__body-wrapper{
		overflow-x: hidden;
	}
	
	 .el-scrollbar{
	    height: 100%;
		overflow-x: hidden;
	}
	
	.el-input{
		width:100%;
	}
	
	.el-input--suffix{
		width: 20vh;
	}
	.el-date-editor.el-input{
		width: 20vh;
	}
	.el-select{
		width: 12%;
		
	}
	.el-input__inner{
		width: 100%
	}

	
	.el-button{
		margin-left: 5px;
	}
</style>