<template>
	<div class="box">
		<div class="header">
			
			<el-form>
				<el-form-item >
					<el-input v-for="sub,index in subjects" :placeholder="sub" suffix-icon="el-icon-collection-tag" v-model="seldata[index]" ></el-input>
					
					
					<el-input placeholder="输入学号" suffix-icon="el-icon-collection-tag" v-model="code"></el-input>
					<el-date-picker placeholder="选择日期" type="date" :picker-options="pickerOptions" v-model="dat"></el-date-picker>
					<el-button icon="el-icon-plus" type="primary" circle @click="addD"></el-button>
					<el-button icon="el-icon-edit" type="primary" circle @click="updateD"></el-button>
					<el-button icon="el-icon-delete" type="primary" circle @click="delD"></el-button>
					<el-button type="primary" circle icon="el-icon-s-open" @click="clear"></el-button>
				</el-form-item>
			</el-form>
			
		</div>
		
		
		
		<div class="foot">
			<el-table :data="grade" border style="width: 100%;" height="100%" class="table"
			@current-change="getrow"
				highlight-current-row>
				<el-table-column label="学号" prop="code"></el-table-column>
				<el-table-column label="语文" prop="subject1"></el-table-column>
				<el-table-column label="数学" prop="subject2"></el-table-column>
				<el-table-column label="英语" prop="subject3"></el-table-column>
				<el-table-column label="历史" prop="subject4"></el-table-column>
				<el-table-column label="物理" prop="subject5"></el-table-column>
				<el-table-column label="地理" prop="subject6"></el-table-column>
				<el-table-column label="生物" prop="subject7"></el-table-column>
				<el-table-column label="化学" prop="subject8"></el-table-column>
				<el-table-column label="政治" prop="subject9"></el-table-column>
				<el-table-column label="日期" prop="date"></el-table-column>
			</el-table>
		</div>
	</div>
</template>

<script>
	export default{
		name:'GradeTable',
		data() {
			return{
				subjects:[],
				grade:[],
				seldata:[],
				pickerOptions:{
				    disabledDate(time) {
				        return time.getTime() > Date.now();
				    }
				},
				code:'',
				dat:''
			}
		},
		methods:{
			getrow(newcr){
				if(newcr){
					var da=[newcr.subject1,newcr.subject2,newcr.subject3,newcr.subject4,
							newcr.subject5,newcr.subject6,newcr.subject7,newcr.subject8,newcr.subject9]
					this.seldata =da
					this.code=newcr.code
					this.dat = newcr.date
				}
			},
			getgrad(){
				$.ajax({
					url:'/api/clsmgent/grade/subject',
					dataType:'json',
					success:(res)=>{
						this.subjects[0]=res.s1;this.subjects[1]=res.s2;this.subjects[2]=res.s3;this.subjects[3]=res.s4
						this.subjects[4]=res.s5;this.subjects[5]=res.s6;this.subjects[6]=res.s7;this.subjects[7]=res.s8
						this.subjects[8]=res.s9;
						this.$forceUpdate()
					}
				})
				
				$.ajax({
					url:'/api/clsmgent/grade/'+this.$user.code,
					type:'patch',
					dataType:'json',
					success:(res)=>{
						this.grade=res
						this.$forceUpdate()
					}
				})				
			},
			addD(){
				let grad={id:null,'code':this.code,'subject1':this.seldata[0],'subject2':this.seldata[1],'subject3':this.seldata[2],
				'subject4':this.seldata[3],'subject5':this.seldata[4],
						'subject6':this.seldata[5],'subject7':this.seldata[6],'subject8':this.seldata[7],'subject9':this.seldata[8],'date':this.dat}
				$.ajax({
					url:'/api/clsmgent/grade/1',
					type:'post',
					data:JSON.stringify(grad),
					contentType:'application/json',
					success:(res)=>{
						if(res == "添加成功"){
							this.$message({message:res,type:'success'})
							this.getgrad()
							return
						}
						this.$message.error(res)
						
					}
				})
			},
			updateD(){
				if(this.seldata.length<9 || !this.code.trim() || this.dat==''){
					this.$message.error('输入正确的信息')
					return
				}
				let grad={id:null,'code':this.code,'subject1':this.seldata[0],'subject2':this.seldata[1],'subject3':this.seldata[2],
				'subject4':this.seldata[3],'subject5':this.seldata[4],
						'subject6':this.seldata[5],'subject7':this.seldata[6],'subject8':this.seldata[7],'subject9':this.seldata[8],'date':this.dat}
				$.ajax({
					url:'/api/clsmgent/grade/1',
					data:JSON.stringify(grad),
					type:'put',
					contentType:'application/json',
					success:(res)=>{
						if(res=='修改成功'){
							this.$message({message:res,type:'success'})
							this.getgrad()
							return
						}
						
						this.$message.error(res)
						
					}
				})
				
			},
			delD(){
				if(this.seldata.length<9 || !this.code.trim() || this.dat==''){
					this.$message.error('输入正确的信息')
					return
				}
				let grad={id:null,'code':this.code,'subject1':this.seldata[0],'subject2':this.seldata[1],'subject3':this.seldata[2],
				'subject4':this.seldata[3],'subject5':this.seldata[4],
						'subject6':this.seldata[5],'subject7':this.seldata[6],'subject8':this.seldata[7],'subject9':this.seldata[8],'date':this.dat}
				$.ajax({
					url:'/api/clsmgent/grade/1',
					data:JSON.stringify(grad),
					type:'delete',
					contentType:'application/json',
					success:(res)=>{
						if(res=='删除成功'){
							this.$message({message:res,type:'success'})
							this.getgrad()
							return
						}
						
						this.$message.error(res)
						
					}
				})
				
			},
			clear(){
				this.seldata=[]
				this.code=''
				this.dat=''
			}
		},
		mounted() {
			this.getgrad()
		}
	}
</script>

<style scoped>
	.box{
		height: 100%;
		width: 100%;
	}
	
	.el-input{
		width: 27vh;
		margin: 5px;
	}
	
	.header{
		height: 30%;
	}
	
	.foot{
		height: 70%;
	}
	
	.el-table{
		height: 100%;
	}
	
</style>