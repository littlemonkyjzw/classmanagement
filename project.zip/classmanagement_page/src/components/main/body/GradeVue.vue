<template>
	<div class="box">
		<div class="pict" id="pict">
			
		</div>
		<div class="info">
			<el-row>
				<el-col :span="8">
					<div>
						<el-statistic :precision="1" :value="total" title="总分"></el-statistic>
					</div>
				</el-col>
				<el-col :span="8">
					<div>
						<el-statistic :precision="2"  :value="avg" title="平均分"></el-statistic>
					</div>
				</el-col>
				<el-col :span="8">
					<div>
						<el-statistic  :value="fra" title="获得积分">
							<template slot="prefix">
							    <i class="el-icon-s-flag" style="color: red"></i>
							</template>
							<template slot="suffix">
							    <i class="el-icon-s-flag" style="color: blue"></i>
							</template>
						</el-statistic>
					</div>
				</el-col>
			</el-row>
		</div>
	</div>
</template>

<script>
	export default{
		name:'GradeVue',
		data() {
			return{
				// grade:{id:1,code:'20030001',subject1:52,subject2:76,subject3:100,subject4:96,subject5:95,
				// subject6:60,subject7:70,subject8:60,subject9:50,date:'2009-06-06'},
				grade:{},
				total:0,
				avg:0,
				fra:0
			}
		},
		
		methods:{
			showData(){
				let mychart = this.$echarts.init(document.getElementById("pict"))
				let vm =this
				//获取科目顺序
				$.ajax({
					url:'/api/clsmgent/grade/subject',
					type:'get',
					dataType:'json',
					success(res){
						option.xAxis.data=[res.s1,res.s2,res.s3,res.s4,res.s5,res.s6,res.s7,res.s8,res.s9]

						$.ajax({
							url:'/api/clsmgent/grade/'+vm.$user.code,
							type:'get',
							dataType:'json',
							success(res){
								
								vm.grade=res
								vm.total=res.subject1+res.subject2+res.subject3+res.subject4+res.subject5
								+res.subject6+res.subject7+res.subject8+res.subject9
								vm.avg=vm.total/9
								if(vm.avg>60){
									vm.fra=1
								}
								option.series[0].data=[{value:vm.grade.subject1,itemStyle:{color:'#e834ff'}},
														{value:vm.grade.subject2,itemStyle:{color:'#18ecff'}},
														{value:vm.grade.subject3,itemStyle:{color:'#15ffa9'}},
														{value:vm.grade.subject4,itemStyle:{color:'#fff014'}},
														{value:vm.grade.subject5,itemStyle:{color:'#ff7010'}},
														{value:vm.grade.subject6,itemStyle:{color:'#b60bff'}},
														{value:vm.grade.subject7,itemStyle:{color:'#ff548a'}},
														{value:vm.grade.subject8,itemStyle:{color:'#85b6ff'}},
														{value:vm.grade.subject9,itemStyle:{color:'#ffce95'}}]
								mychart.setOption(option)
							}
						})
					}
				})
				


			},
		},
		mounted() {
			this.showData()
		}
	}
	var option = {
		title:[{text:'最近一次个人成绩',left:'center'}],
		  xAxis: {
			type: 'category',
		  },
		  yAxis: {
			type: 'value'
		  },
		  tooltip:{},
		  series: [
			{
			  type: 'bar'
			}
		  ],
	  
	};
	
</script>

<style scoped>
	


	.box{
		height: 100%;
	}
	.pict{
		width: 100%;
		height: 80%;
	}
	.info{
		height: 20%;
		width: 100%;
	}
</style>