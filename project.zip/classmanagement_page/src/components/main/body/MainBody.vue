<template>
	<div class="mainbox">
		<BaseInfoView v-if="isShow==0"></BaseInfoView>
		<GradVue v-if="isShow==2"></GradVue>
		<GradeTable v-if="isShow==1"></GradeTable>
		<MainScreen v-if="isShow==10"></MainScreen>
	</div>
</template>

<script>
	
	import GradVue from './GradeVue.vue'
	import BaseInfoView from './BaseInfoView.vue'
	import GradeTable from './GradeTable.vue'
	import MainScreen from './visualscreen/main.vue'
	
	
	export default{
		name:'MainBody',
		data() {
			return{
				isShow:0
			}
		},
		components:{
			GradVue,BaseInfoView,GradeTable,MainScreen
		},
		mounted() {
			this.$bus.$on('showPage',(s)=>{
				this.isShow=s
			})
		}
	}
</script>

<style scoped>
	.mainbox{
		width: 100%;
		height: 100%;
		margin: 0;
		padding: 0;
	}
</style>