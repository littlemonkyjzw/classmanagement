<template>
	<div class="box"> 
		<el-container>
			<!-- 导航栏 -->
				<el-aside width="200px" class="aside" v-if="screen == 0">
					<el-scrollbar wrap-style="overflow-x:hidden;">
						<MainAside></MainAside>
					</el-scrollbar>
				</el-aside>


				<el-container>
					<!-- 头部 -->
				<el-header class="eheader" v-if="screen == 0">
				  <div class="header">
					  <Header></Header>
				  </div>
				</el-header> 
				
				<!-- 主体 -->
				<el-main class="main" :style="screenStyle" >
					<MainBody></MainBody>
				</el-main>
			  </el-container>
		</el-container>		
	</div>

</template>

<script>
	import MainAside from './aside/MainAside.vue'
	import Header from './header/Header.vue'
	import MainBody from './body/MainBody.vue'
	
	export default{
		name:'Main',
		props:['isShow'],
		
		components:{
			MainAside,Header,MainBody
		},
		data() {
			return{
				screen:0,
				screenStyle:'padding: 20px;'
			}
		},
		beforeMount() {
			this.$bus.$on('showScreen',(s)=>{
				this.screen=s
				if(s==1){
					this.screenStyle='padding: 0;'
				}else{
					this.screenStyle='padding: 20px;'
				}
			})
			if(!this.$user.code){ 
				this.isShow(false)
			}
		}
	}
</script>

<style scoped>
	.eheader{
		padding: 0;
	}
	.header{
		height: 100%;
		padding: 0px;
	}
	.aside{
		background-color: #55586c;
		position: relative;
		height: 100%;
		overflow-x: hidden;
		display: inline-block;
		font-size: 30px;
	}
	.main{
	}
	.box{
		padding: 0;
		height: 100%;
		position: fixed;
		background-size: 100% 100%;
		width: 100%;
		height: 100%;
		top:0;
		left: 0;
	}
	 .el-scrollbar{
	    /* width: 100%; */
	    height: 100%;
		overflow-x: hidden;
	}
	.el-container{
		height: 100%;
	}
	/* .el-scrollbar .el-scrollbar__wrap{overflow-x: hidden;} */
</style>