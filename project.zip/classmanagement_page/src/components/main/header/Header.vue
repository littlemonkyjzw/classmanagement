<template>
	<el-card class="header" shadow="always" >
		<el-row>
			<el-col>
				<span>{{position}},{{name}}</span>
				<el-avatar :size="30" :src="circleUrl" class="imghead"></el-avatar>					
			</el-col>
		</el-row>
				


	</el-card>
</template>

<script>
	export default{
		name:'Header',
		data() {
			return{
				position:'班主任',
				name:'班主任',
				circleUrl: "https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"
			}
		},
		mounted() {
			this.position = this.$user.stupos
			this.name = this.$user.stuname
		}
	}
</script>

<style scoped>

	.header{
		height: 100%;
		width: 100%;
		width: 100%;
		height: 100%;
		text-align: right;
		float: right;
		padding-top: 0px;
	}
	span{
		margin: auto 20px;
	}
	
	.imghead:hover{
		cursor: pointer;
	}
	
	
	
	
</style>