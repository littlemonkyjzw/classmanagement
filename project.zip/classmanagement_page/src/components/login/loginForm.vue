<template>
	<div id="bg">
		<div id="login">
			<el-form label-position="left" class="fom" :rules="rules" :model="ruleForm">
				<div class="title">
					班级管理系统
				</div> 
				<hr />
				<br>
				<el-form-item label="学号:" label-width="70px" prop="code" >
					<el-input autocomplete="off" v-model="ruleForm.code"></el-input>
				</el-form-item>
				
				<el-form-item label="密码:" label-width="70px" prop="password" >
					<el-input type="password"  autocomplete="off" v-model="ruleForm.password"></el-input>
				</el-form-item>
				
				<el-form-item>
					<el-button type="primary" round class="btn" @click="login">
						登录
					</el-button>
				</el-form-item>

			</el-form>
		</div>		
	</div>

</template>

<script>
	export default{
		name:'Login',
		props:['isShow'],
		data() {
			return{
				ruleForm:{
					password:'',
					code:''
				},
				rules:{
					password:[{required:true,message:'密码不能为空', trigger: 'blur'}],
					code:[{required:true,message:'用户名不能为空', trigger: 'blur'}]
				}

			}
		},
		methods:{
			login(){
				//调用登录方法
				if(this.ruleForm.code.trim() && this.ruleForm.password.trim()){
					this.f_login(this.ruleForm.code,this.ruleForm.password,this)
				}
			},
			f_login(code,password,vm){
				$.ajax({
					url:'/api/clsmgent/login',
					data:JSON.stringify({'code':code,'password':password}),
					contentType: "application/json;charset=UTF-8",
					type:'post',
					success(res) {
						if(res != '登录成功'){
							vm.$message.error(res)
							return
						}
							vm.$message({
								message:'登录成功',
								type:'success'
							});
							$.ajax({
								url:'/api/clsmgent/ShowStuInfo/'+vm.ruleForm.code,
								dataType:'json',
								type:'get',
								success(resp){
									vm.$user.code=resp.code
									vm.$user.stuaddress=resp.stuaddress
									vm.$user.stubirth=resp.stubirth
									vm.$user.stugender=resp.stugender
									vm.$user.stugenderCode=resp.stugenderCode
									vm.$user.stuname=resp.stuname
									vm.$user.stuphone=resp.stuphone
									vm.$user.stupos=resp.stupos
									vm.$user.stuposCode=resp.stuposCode
									vm.isShow(true);
								}
							})
					},
				})
			}
			
		}
	}
	
	

</script>

<style scoped>
	@import url("//unpkg.com/element-ui@2.15.13/lib/theme-chalk/index.css");
	#bg{
		background-image: url('../../assets/bgimg/login_bg.jpg');
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-size: 100% 100%;
		margin: 0%;
		float: right;
	}
	#login{
		padding: 30px;
		background-color: white;
		width: 300px;
		height: 300px;
		border-radius: 10px;
		position: absolute;
		right: 10%;
		top: 25%;
		box-shadow:-10px 10px 10px -4px;
		
	}
	.btn{
		width: 100%;
	}

	.fom{
		margin: auto;
	}
	.title{
		text-align: center;
		margin: 30px;
		margin-bottom: 5px;
		font-family: '黑体';
		font-weight: 300;
		font-size: 30px;
	}
</style>