<template>
  <div id="app">
	<Login :isShow="setIsShow" v-if="!isShow"></Login>
	<Main v-if="isShow" :isShow="setIsShow"></Main>
  </div>
  
</template>

<script>

import Login from './components/login/loginForm.vue'
import Main from './components/main/main.vue'

export default {
  name: 'App',
  data() {
  	return{
		isShow:false
	}
  },
  methods:{
	  setIsShow(flag){
		  this.isShow=flag;
	  }
  },
  components: {
	  Login,Main
  }
}
</script>

<style>

</style>
