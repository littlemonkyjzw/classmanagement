package com.clsmagent.mapper;

import com.clsmagent.pojo.entry.SubjectSort;

public interface SubjectSortMapper {
    SubjectSort getSubjectSort();

    int setSubjectSort(SubjectSort subjectSort);
}
