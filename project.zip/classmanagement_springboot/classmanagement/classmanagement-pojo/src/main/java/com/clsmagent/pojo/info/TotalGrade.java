package com.clsmagent.pojo.info;

import java.sql.Date;

public class TotalGrade {
    private Date date;
    private Integer total;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}
