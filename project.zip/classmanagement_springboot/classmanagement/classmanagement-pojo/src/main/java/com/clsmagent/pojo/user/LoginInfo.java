package com.clsmagent.pojo.user;

public class LoginInfo {
    private String stuname;
    private String code;
    private String stupos;
    private String stuimg;

    public String getStuname() {
        return stuname;
    }

    public void setStuname(String stuname) {
        this.stuname = stuname;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStupos() {
        return stupos;
    }

    public void setStupos(String stupos) {
        this.stupos = stupos;
    }

    public String getStuimg() {
        return stuimg;
    }

    public void setStuimg(String stuimg) {
        this.stuimg = stuimg;
    }
}
