package com.clsmagent.pojo.entry;

import java.sql.Date;

public class Grade {
    private int id;
    private String code;
    private float subject1;
    private float subject2;
    private float subject3;
    private float subject4;
    private float subject5;
    private float subject6;
    private float subject7;
    private float subject8;
    private float subject9;
    private Date date;
    private String desc;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public float getSubject1() {
        return subject1;
    }

    public void setSubject1(float subject1) {
        this.subject1 = subject1;
    }

    public float getSubject2() {
        return subject2;
    }

    public void setSubject2(float subject2) {
        this.subject2 = subject2;
    }

    public float getSubject3() {
        return subject3;
    }

    public void setSubject3(float subject3) {
        this.subject3 = subject3;
    }

    public float getSubject4() {
        return subject4;
    }

    public void setSubject4(float subject4) {
        this.subject4 = subject4;
    }

    public float getSubject5() {
        return subject5;
    }

    public void setSubject5(float subject5) {
        this.subject5 = subject5;
    }

    public float getSubject6() {
        return subject6;
    }

    public void setSubject6(float subject6) {
        this.subject6 = subject6;
    }

    public float getSubject7() {
        return subject7;
    }

    public void setSubject7(float subject7) {
        this.subject7 = subject7;
    }

    public float getSubject8() {
        return subject8;
    }

    public void setSubject8(float subject8) {
        this.subject8 = subject8;
    }

    public float getSubject9() {
        return subject9;
    }

    public void setSubject9(float subject9) {
        this.subject9 = subject9;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
