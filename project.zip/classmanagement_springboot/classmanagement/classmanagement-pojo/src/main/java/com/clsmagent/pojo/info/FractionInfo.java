package com.clsmagent.pojo.info;

public class FractionInfo {
    private String code;
    private Integer fra;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getFra() {
        return fra;
    }

    public void setFra(Integer fra) {
        this.fra = fra;
    }
}
