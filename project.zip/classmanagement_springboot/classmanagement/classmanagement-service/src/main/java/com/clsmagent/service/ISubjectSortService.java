package com.clsmagent.service;

import com.clsmagent.pojo.entry.SubjectSort;

public interface ISubjectSortService {
    SubjectSort getSubjectSort();

    String setSubjectSort(SubjectSort subjectSort);
}
